local config = require("kg.config")
local crypto = require("kg.crypto")
local transport = require("kg.transport")
local models = require("kg.models")

local discover = {}

-- 缓存歌曲 hash 到云端歌单 fileid 的映射 (用于取消喜欢时精确删除)
discover.fileIdMap = {}

-- 拉取私人漫游歌曲流
function discover.getPersonalFmSongs(mode, songPoolId)
  local session = transport.getSession()
  local userId = (session and session.userId and session.userId ~= "0") and session.userId or ""
  local token = (session and session.token) or ""
  local mid = (session and session.mid) or config.defaultMid

  local nowMs = host.now()
  local nowMsStr = string.format("%.0f", nowMs)
  local key = crypto.calc_login_key(nowMsStr)

  local body = {
    appid = tonumber(config.appId) or 3116,
    clienttime = math.floor(nowMs),
    mid = mid,
    action = "play",
    recommend_source_locked = 0,
    song_pool_id = songPoolId or 0,
    callerid = 0,
    m_type = 1,
    platform = "android",
    area_code = 1,
    remain_songcnt = 0,
    clientver = tonumber(config.clientVer) or 11440,
    is_overplay = 0,
    mode = mode or "normal",
    fakem = "ca981cfc583a4c37f28d2d49000013c16a0a",
    key = key,
    vip_type = "0"
  }

  if userId ~= "" then
    body.userid = tostring(userId)
    body.kguid = tostring(userId)
  end
  if token ~= "" then
    body.token = token
  end

  local res, err = transport.request({
    method = "POST",
    path = "/v2/personal_recommend",
    router = "persnfm.service.kugou.com",
    body = body
  })

  local songs = {}
  local list = res and res.data and (res.data.song_list or res.data.songs)
  if list and type(list) == "table" then
    for _, item in ipairs(list) do
      local s = models.song(item)
      if s and s.id and s.id ~= "" then
        table.insert(songs, s)
      end
    end
  end

  transport.debugLog("getPersonalFmSongs mode=" .. tostring(mode) .. " res=" .. tostring(res and res.status) .. " count=" .. tostring(#songs))
  return songs
end

-- 首页推荐流 (homeFeed)
function discover.homeFeed()
  local session = transport.getSession()
  local userId = (session and session.userId and session.userId ~= "0") and session.userId or "0"

  -- 1. 获取推荐歌单 (拉取 30 个，分别分配给 recommended 和 playlists，避免内容重复)
  local nowSec = math.floor(host.now() / 1000)
  local key = crypto.calc_login_key(tostring(nowSec))
  local plRes, err = transport.request({
    method = "POST",
    path = "/v2/special_recommend",
    router = "specialrec.service.kugou.com",
    body = {
      appid = tonumber(config.appId) or 3116,
      mid = (session and session.mid) or config.defaultMid,
      clientver = tonumber(config.clientVer) or 11440,
      platform = "android",
      clienttime = nowSec,
      userid = tostring(userId),
      module_id = 1,
      page = 1,
      pagesize = 30,
      key = key,
      special_recommend = {
        withtag = 1,
        withsong = 0,
        sort = 1,
        ugc = 1,
        is_selected = 0,
        withrecommend = 1,
        area_code = 1,
        categoryid = 0
      },
      req_multi = 1,
      retrun_min = 5,
      return_special_falg = 1
    }
  })

  local allPlaylists = {}
  if plRes and plRes.data and plRes.data.special_list then
    for _, item in ipairs(plRes.data.special_list) do
      local p = models.playlist(item)
      if p and p.id and p.id ~= "" then
        table.insert(allPlaylists, p)
      end
    end
  end

  local recommended = {}
  local otherPlaylists = {}
  for i, pl in ipairs(allPlaylists) do
    if i <= 10 then
      table.insert(recommended, pl)
    else
      table.insert(otherPlaylists, pl)
    end
  end
  if #otherPlaylists == 0 then
    otherPlaylists = recommended
  end

  -- 2. 获取每日推荐歌曲
  local songRes, sErr = transport.request({
    method = "POST",
    path = "/everyday_song_recommend",
    router = "everydayrec.service.kugou.com",
    body = {
      platform = "android",
      userid = tostring(userId)
    }
  })

  local dailySongs = {}
  if songRes and songRes.data and songRes.data.song_list then
    for _, item in ipairs(songRes.data.song_list) do
      local s = models.song(item)
      if s and s.id and s.id ~= "" then
        table.insert(dailySongs, s)
      end
    end
  end

  -- 3. 获取快速聆听 / 私人漫游歌曲 (让 quick 与 daily 彻底区分)
  local quickSongs = discover.getPersonalFmSongs("normal", 0)
  if #quickSongs == 0 then
    quickSongs = dailySongs
  end

  return {
    daily = dailySongs,
    quick = quickSongs,
    recommended = recommended,
    playlists = otherPlaylists,
    albums = {},
    featuredSongs = {}
  }
end

-- 用户个人歌单列表 (playlists) - 对应酷狗云端自建与收藏歌单 (/v7/get_all_list)
function discover.playlists(args)
  local session = transport.getSession()
  if not session or not session.userId or session.userId == "0" or not session.token or session.token == "" then
    transport.debugLog("discover.playlists: no session, return empty")
    return {}
  end

  local limit = tonumber(args and args.limit or 50)
  local offset = tonumber(args and args.offset or 0)
  local page = math.floor(offset / limit) + 1

  transport.debugLog("discover.playlists start page=" .. tostring(page) .. " limit=" .. tostring(limit))

  local res, err = transport.request({
    method = "POST",
    path = "/v7/get_all_list",
    params = {
      plat = "1",
      userid = tostring(session.userId),
      token = session.token
    },
    body = {
      userid = tostring(session.userId),
      token = session.token,
      total_ver = 979,
      type = 2,
      page = page,
      pagesize = limit
    },
    router = "cloudlist.service.kugou.com"
  })

  local list = {}
  local info = res and res.data and res.data.info
  if info and type(info) == "table" then
    for _, item in ipairs(info) do
      -- 剔除“我喜欢” (is_def == 2)，因为宿主通过 favorites 单独管理并在置顶以特权显示
      local isDef = tonumber(item.is_def or 0)
      if isDef ~= 2 then
        local p = models.playlist(item, session)
        if p and p.id and p.id ~= "" then
          table.insert(list, p)
        end
      end
    end
  end

  transport.debugLog("discover.playlists done count=" .. tostring(#list) .. " err=" .. tostring(err))
  return list
end

-- 收藏歌曲列表 (favorites) - 对应酷狗云端“我喜欢”歌单 (listid = 2)
function discover.favorites(args)
  local session = transport.getSession()
  if not session or not session.userId or session.userId == "0" or not session.token or session.token == "" then
    transport.debugLog("discover.favorites no session")
    return {}
  end

  local limit = tonumber(args and args.limit or 100)
  local offset = tonumber(args and args.offset or 0)
  local page = math.floor(offset / limit) + 1

  transport.debugLog("discover.favorites start page=" .. tostring(page) .. " limit=" .. tostring(limit))

  local res, err = transport.request({
    method = "POST",
    path = "/v4/get_list_all_file",
    router = "cloudlist.service.kugou.com",
    body = {
      listid = 2, -- 酷狗“我喜欢”歌单
      userid = tostring(session.userId),
      token = session.token,
      type = 0,
      page = page,
      pagesize = limit,
      area_code = 1,
      allplatform = 1,
      show_cover = 1,
      show_relate_goods = 0
    }
  })

  local songs = {}
  local list = res and res.data and res.data.info
  transport.debugLog("discover.favorites res=" .. tostring(res and res.status) .. " rawCount=" .. tostring(list and #list or 0))

  if list and type(list) == "table" then
    for _, item in ipairs(list) do
      local okSong, s = pcall(models.song, item)
      if okSong and s and s.id and s.id ~= "" then
        s.starred = true
        local h = s.id:lower()
        if item.fileid then
          discover.fileIdMap[h] = item.fileid
        end
        table.insert(songs, s)
      else
        transport.debugLog("models.song fail: " .. tostring(s))
      end
    end
  end

  transport.debugLog("discover.favorites done songs=" .. tostring(#songs))
  return songs
end

return discover
